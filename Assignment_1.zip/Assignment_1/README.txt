Name: Deepa Choudhary W1547335

Programming Assignment 1: Client using customized protocol on top of UDP protocol for sending information to the server. One client connects to one server.

1) Open terminal and compile the server1.c file using "gcc -o server1 server1.c"     
2) Open another terminal and compile the client1.c file using "gcc -o client1 client1.c"
3) Run the server first by using "./server1"
4) Run the client using "./client1" it will begin transmitting packets to the server1. 
5) The output of the program will be similar to the screenshots attached in the Output folder.

