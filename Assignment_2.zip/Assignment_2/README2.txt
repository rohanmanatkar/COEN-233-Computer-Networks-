Name: Deepa Choudhary W1547335

Programming Assignment 2: Client using customized protocol on top of UDP protocol for requesting identification from server for access permission to the network. One client connects to one server.


1) Open terminal and compile the server2.c file using "gcc -o server2 server2.c"     
2) Open another terminal and compile the client2.c file using "gcc -o client2  client2.c"
3) Run the server first using "./server2"
4) Run the client using "./client2" it will begin transmitting packets to the server2. 
5) The output of the program will be similar to the screenshots attached in the Output  folder.

